// DemoGame.cpp : Defines the entry point for the application.
//
#include "stdafx.h"
#include "DemoGame.h"
#include "Actor.h"
#include "StringUtils.h"

int APIENTRY _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	DemoGame game(hInstance);

	if (game.Initialize(_T("Demo Game")))
	{
		return game.Run(1024, 768, false);
	}

	return -99;
}

bool DemoGame::LoadGameScene()
{
	// Load image resources
	GetAssetsManager().AddImage(_T("Background"), _T("background3.jpg"), false, 0, 0, 0);
	GetAssetsManager().AddImage(_T("Petric"), _T("Petric.png"), true, 0, 0, 0);
	GetAssetsManager().AddImage(_T("Tomato"), _T("Tomato.png"), true, 0, 0, 0);
	GetAssetsManager().AddImage(_T("Monti"), _T("monti.png"), true, 0, 0, 0);
	GetAssetsManager().AddImage(_T("John"), _T("John.png"), true, 3, 32, 58);
	GetAssetsManager().AddImage(_T("RedBullet"), _T("redbullet.png"), true, 0, 0, 0);
	GetAssetsManager().AddImage(_T("Fire"), _T("explosion_anim.png"), true, 1, 40, 40);

	// Load game entities for the level
	vector<wstring> levelDataPropertyNames;
	levelDataPropertyNames.push_back(_T("x"));
	levelDataPropertyNames.push_back(_T("y"));
	levelDataPropertyNames.push_back(_T("Name"));
	levelDataPropertyNames.push_back(_T("Type"));
	levelDataPropertyNames.push_back(_T("ImageName"));

	vector<map<wstring, wstring>> levelDataItems = GetLevelDataManager().LoadLevelData(_T("Level1.xml"), _T("LevelData"), levelDataPropertyNames);

	for (vector<map<wstring, wstring>>::iterator levelDataItemsIter = levelDataItems.begin(); levelDataItemsIter != levelDataItems.end(); levelDataItemsIter++)
	{
		map<wstring, wstring> levelDataItem = *levelDataItemsIter;

		map<wstring, wstring>::iterator levelDataItemIter = levelDataItem.find(_T("Type"));
		if (levelDataItemIter == levelDataItem.end())
		{
			// error???
			continue;
		}

		// Check for valid entityType value.
		int entityTypeVal = string2X::string2int(levelDataItemIter->second);
		EntityTypes entityType = static_cast<EntityTypes>(entityTypeVal);
		if (entityType < background || entityType > simpleProjectile)
		{
			// error???
			continue;
		}

		levelDataItemIter = levelDataItem.find(_T("Name"));
		if (levelDataItemIter == levelDataItem.end())
		{
			// error???
			continue;
		}
		wstring entityName = levelDataItemIter->second;

		levelDataItemIter = levelDataItem.find(_T("x"));
		if (levelDataItemIter == levelDataItem.end())
		{
			// error???
			continue;
		}
		float xPos = string2X::string2float(levelDataItemIter->second);

		levelDataItemIter = levelDataItem.find(_T("y"));
		if (levelDataItemIter == levelDataItem.end())
		{
			// error???
			continue;
		}
		float yPos = string2X::string2float(levelDataItemIter->second);

		levelDataItemIter = levelDataItem.find(_T("ImageName"));
		if (levelDataItemIter == levelDataItem.end())
		{
			// error???
			continue;
		}
		wstring imageName = levelDataItemIter->second;

		switch (entityType)
		{
			case tile:
				{
					Entity* pEntity = new Entity();
					pEntity->Initialize(entityName, entityType, imageName, VECTOR2D(xPos, yPos), Entity::collidable);
					GetSceneManager().AddEntity(pEntity);
				}
				break;

			case avatar:
				m_john.Initialize(entityName, entityType, imageName, VECTOR2D(xPos, yPos), Entity::collidable);
				m_john.AddAnimation(_T("walk_right"), 0, 0, 8, 15, true);
				m_john.AddAnimation(_T("walk_left"), 2, 0, 8, 15, true);
				m_john.AddAnimation(_T("jump_right"), 1, 0, 1, 1, true);
				m_john.AddAnimation(_T("jump_left"), 1, 2, 1, 1, true);
				m_john.AddAnimation(_T("idle_right"), 1, 1, 1, 1, true);
				m_john.AddAnimation(_T("idle_left"), 1, 3, 1, 1, true);
				m_john.PlayAnimation(_T("idle_right"));
				m_john.AddMotion(VECTOR2D(200, 200), VECTOR2D(100, 100), 500);
				m_john.AddShooting(simpleProjectile, 20, 0.2f);
				//m_john.AddJumping(450, -150, 1.5);
				m_john.SetHeading(MovableEntity::right);
				break;
		}
	}

	// Setup special game entities
	m_background.Initialize(_T("background"), _T("Background"));
	m_score.Initialize(_T("score"), _T("Score: 0"), VECTOR2D(100, 30), RGB(255, 255, 0), 20);

	m_tomato.Initialize(_T("tomato"), collectible, _T("Tomato"), VECTOR2D(600, 536), Entity::trigger);
	m_tomato.SetScore(100);
	GetSceneManager().AddEntity(&m_tomato);

	m_enemy.Initialize(_T("monti"), agent, _T("Monti"), VECTOR2D(500, 200), Entity::collidable);
	m_enemy.AddWandering();
	m_enemy.SetVelocity(VECTOR2D(1, 1));
	GetSceneManager().AddEntity(&m_enemy);

	ProjectileImpactEffect projectileImpactEffect;
	projectileImpactEffect.m_impactAnimationImageName = _T("Fire");
	projectileImpactEffect.m_impactAnimationIndex = 0;
	projectileImpactEffect.m_startFrame = 0;
	projectileImpactEffect.m_numberOfFrames = 9;
	projectileImpactEffect.m_framesPerSecond = 10;

	GetSceneManager().CreateProjectilesPool(simpleProjectile, _T("RedBullet"), 100, VECTOR2D(500, 500), projectileImpactEffect);
	GetSceneManager().SetupScene(&m_background, &m_john, VECTOR2D(100, 100), SceneManager::both);

	return true;
}

void DemoGame::UpdateGameScene(GameTime& gameTime)
{
	bool inputActive = false, canJump = true;

	KeyboardState keyboardState = GetKeyboardState();

	if (keyboardState.IsKeyboardKeyDown(VK_LEFT) && keyboardState.IsKeyboardKeyDown(VK_UP))
	{
		m_john.GetMotion().SetMotionDirection(Motion::left_upward);
		m_john.SetHeading(MovableEntity::left);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_left"));
		}
		inputActive = true;
		canJump = false;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_LEFT) && keyboardState.IsKeyboardKeyDown(VK_DOWN))
	{
		m_john.GetMotion().SetMotionDirection(Motion::left_downward);
		m_john.SetHeading(MovableEntity::left);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_left"));
		}
		inputActive = true;
		canJump = false;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_RIGHT) && keyboardState.IsKeyboardKeyDown(VK_UP))
	{
		m_john.GetMotion().SetMotionDirection(Motion::right_upward);
		m_john.SetHeading(MovableEntity::right);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_right"));
		}
		inputActive = true;
		canJump = false;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_RIGHT) && keyboardState.IsKeyboardKeyDown(VK_DOWN))
	{
		m_john.GetMotion().SetMotionDirection(Motion::right_downward);
		m_john.SetHeading(MovableEntity::right);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_right"));
		}
		inputActive = true;
		canJump = false;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_LEFT))
	{
		m_john.GetMotion().SetMotionDirection(Motion::left);
		m_john.SetHeading(MovableEntity::left);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_left"));
		}
		inputActive = true;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_RIGHT))
	{
		m_john.GetMotion().SetMotionDirection(Motion::right);
		m_john.SetHeading(MovableEntity::right);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("walk_right"));
		}
		inputActive = true;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_UP))
	{
		m_john.GetMotion().SetMotionDirection(Motion::upward);
		m_john.SetHeading(MovableEntity::up);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("jump_right"));
		}
		inputActive = true;
	}
	else if (keyboardState.IsKeyboardKeyDown(VK_DOWN))
	{
		m_john.GetMotion().SetMotionDirection(Motion::downward);
		m_john.SetHeading(MovableEntity::down);
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.PlayAnimation(_T("jump_left"));
		}
		inputActive = true;
	}

	if (canJump && keyboardState.IsKeyboardKeyDown(VK_SPACE))
	{
 		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())
		{
			m_john.GetJumping().StartJumping(gameTime);
			m_john.PlayAnimation((m_john.GetHeading() == MovableEntity::right) ? _T("jump_right") : _T("jump_left"));
			inputActive = true;
		}
		else if (keyboardState.WasKeyboardKeyDown(VK_SPACE))
		{
			m_john.GetJumping().RetainJumpingIfNeeded(gameTime);
			m_john.PlayAnimation((m_john.GetHeading() == MovableEntity::right) ? _T("jump_right") : _T("jump_left"));
			inputActive = true;
		}
	}

	if (keyboardState.IsKeyboardKeyDown(0x41))
	{
		m_john.GetShooting().Shoot(gameTime);
	}

	if (!inputActive)   // no user input
	{
		if (!m_john.GetJumping().GetIsJumping() && !m_john.GetJumping().GetIsFalling())   // no jumping/falling
		{
			m_john.GetMotion().SetMotionDirection(Motion::none);   // idle...

			switch (m_john.GetHeading())
			{
				case MovableEntity::left:
					m_john.PlayAnimation(_T("idle_left"));
					break;

				case MovableEntity::right:
					m_john.PlayAnimation(_T("idle_right"));
					break;
			}
		}

		//jumpingStartTime = 0;   // reset the jumping timer.
	}

	m_john.Update(gameTime);
	m_enemy.Update(gameTime);

	TCHAR score[20];
	_stprintf_s(score, _T("Score:%d"), m_john.GetScore());
	m_score.SetText(score);
	m_score.Update(gameTime);
}

void DemoGame::DrawGameScene(GameTime& gameTime)
{
	// First, draw the background.
	m_background.Draw(gameTime);

	// Draw the special game entities.
	m_tomato.Draw(gameTime);
	m_john.Draw(gameTime);

	// Draw the HUD.
	m_score.Draw(gameTime);
}

void DemoGame::CollisionDetected(Entity* pCollider, CollisionDetector::CollisionDirection direction, bool& cancelDetection)
{
	if ((pCollider->GetType() == tile) && (direction == CollisionDetector::left || direction == CollisionDetector::right))
	{
		switch (m_john.GetHeading())
		{
			case MovableEntity::left:
				m_john.PlayAnimation(_T("idle_left"));
				break;

			case MovableEntity::right:
				m_john.PlayAnimation(_T("idle_right"));
				break;
		}
	}
}

void DemoGame::TriggerDetected(Entity* pTrigger, bool& cancelDetection)
{
	if (pTrigger->GetType() == collectible)
	{
		Collectible* pCollectible = static_cast<Collectible*>(pTrigger);
		if (pCollectible != NULL)
		{
			pCollectible->SetIsActive(false);

			int score = pCollectible->GetScore();
			m_john.SetScore(score);
		}
	}
}

void DemoGame::ProjectileImpactDetected(Entity* pAffected, bool& cancelDetection)
{
}

#pragma once

#include "resource.h"
#include "GameApp.h"
#include "Background.h"
#include "Entity.h"
#include "Agent.h"
#include "Collectible.h"
#include "Avatar.h"
#include "TextLabel.h"

class DemoGame : public GameApp
{
public:
	DemoGame(HINSTANCE hInstance) : GameApp(hInstance) {}

private:
	enum EntityTypes
	{
		background, tile, collectible, avatar, simpleProjectile, agent
	};

private:
	bool LoadGameScene();
	void UpdateGameScene(GameTime& gameTime);
	void DrawGameScene(GameTime& gameTime);
	void CollisionDetected(Entity* pCollider, CollisionDetector::CollisionDirection direction, bool& cancelDetection);
	void TriggerDetected(Entity* pTrigger, bool& cancelDetection);
	void ProjectileImpactDetected(Entity* pAffected, bool& cancelDetection);

private:
	Background m_background;
	Collectible m_tomato;
	Agent m_enemy;
	Avatar m_john;
	TextLabel m_score;
};

#pragma once

#pragma warning(disable: 4251)

#include "GSEngineExports.h"
#include "GSGraphicsTypes.h"
#include "GameFoundationClasses.h"
#include "GameTime.h"

////////////////////////////////////////////////////////////
// Declaration of the Motion class.
//
class GSENGINE_API Motion : public Updateable
{
	// Provide an access to Motion's private members for the followings:
	friend class Avatar;

public:
	enum MotionDirection
	{
		none, left, right, upward, downward, left_upward, left_downward, right_upward, right_downward
	};

public:
	// Construction
	Motion();
	Motion(VECTOR2D velocity, VECTOR2D acceleration, float maxVelocity);

	// Methods
	virtual void Update(GameTime& gameTime);

	// Attributes
	MotionDirection GetMotionDirection() const { return m_motionDirection; }
	VECTOR2D GetMovement() const { return m_movement; }
	VECTOR2D GetVelocity() const { return m_velocity; }
	VECTOR2D GetAcceleration() const { return m_acceleration; }
	void SetMotionDirection(MotionDirection motionDirection) { m_motionDirection = motionDirection; }
	void SetVelocity(VECTOR2D velocity) { m_velocity = velocity; }
	void SetAcceleration(VECTOR2D acceleration) { m_acceleration = acceleration; }
	void SetMaxVelocity(float maxVelocity) { m_maxVelocity = maxVelocity; }

private:
	bool IsMotionChangedToOppositeDirection();

private:
	MotionDirection m_motionDirection, m_prevMotionDirection;
	VECTOR2D m_movement;
	VECTOR2D m_velocity;
	VECTOR2D m_acceleration;
	float m_maxVelocity;
	bool m_keepGravityMovement;   // set by Avatar object!!!
};

////////////////////////////////////////////////////////////
// Declaration of the Jumping class.
//
class GSENGINE_API Jumping : public Updateable
{
	// Provide an access to Motion's private members for the followings:
	friend class Avatar;

public:
	// Construction
	Jumping();
	Jumping(float gravity, float impulse, float maxImpulseTime);

	// Methods
	virtual void Update(GameTime& gameTime);
	void StartJumping(GameTime& gameTime);
	void RetainJumpingIfNeeded(GameTime& gameTime);

	// Attributes
	VECTOR2D GetMovement() const { return m_movement; }
	VECTOR2D GetVelocity() const { return m_velocity; }
	bool GetIsJumping() const { return m_isJumping; }
	bool GetIsFalling() const { return m_isFalling; }
	void SetGravity(float gravity) { m_gravity = gravity; }
	void SetImpulse(float impulse) { m_impulse = impulse; }
	void SetMaxImpulseTime(float maxImpulseTime) { m_maxImpulseTime = maxImpulseTime; }

private:
	bool m_emptyBehavior;   // set by Avatar object!!!
	VECTOR2D m_movement;
	VECTOR2D m_velocity;
	bool m_isJumping, m_isFalling;
	float m_gravity;
	float m_impulse, m_maxImpulseTime;
	double m_jumpingStartTime;
};

// Forward declarations
class Actor;

////////////////////////////////////////////////////////////
// Declaration of the Shooting class.
//
class GSENGINE_API Shooting
{
public:
	// Construction
	Shooting();
	Shooting(Actor* pShooter, UINT type, int capacity, float pause);

	// Methods
	void Shoot(GameTime& gameTime);

	// Attributes
	UINT GetType() const { return m_type; }
	int GetCapacity() const { return m_capacity; }
	float GetPause() const { return m_pause; }
	void SetType(UINT type) { m_type = type; }
	void SetCapacity(int capacity) { m_capacity = capacity; }
	void SetPause(float pause) { m_pause = pause; }

private:
	Actor* m_pShooter;
	UINT m_type;
	int m_capacity;
	float m_pause;
	double m_timeSincePreviousShot;
};

// Forward declarations
class Agent;

////////////////////////////////////////////////////////////
// Declaration of the Steering abstract class.
// 
// All derived steering behaviors are implementing the steering algorithms 
// proposed by Craig Reynolds.
//
class GSENGINE_API Steering
{
public:
	// Methods
	virtual VECTOR2D Perform(Agent* pAgent) = 0;
};

////////////////////////////////////////////////////////////
// Declaration of the Wandering class.
//
class GSENGINE_API Wandering : public Steering
{
public:
	// Construction
	Wandering();
	Wandering(float aheadCircleDistance, float aheadCircleRadius, float displacementAngleChange);

	// Methods
	virtual VECTOR2D Perform(Agent* pAgent);

private:
	float m_aheadCircleDistance, m_aheadCircleRadius;
	float m_displacementAngle, m_displacementAngleChange;
};

#include "stdafx.h"
#include "Behaviors.h"
#include "GameApp.h"
#include "GameException.h"
#include "Projectile.h"
#include "Agent.h"
#include <ctime>

////////////////////////////////////////////////////////////
// Definitions for the Motion class.
//
Motion::Motion() : 
	m_motionDirection(none),
	m_prevMotionDirection(none),
	m_maxVelocity(0),
	m_keepGravityMovement(false)
{
}

Motion::Motion(VECTOR2D velocity, VECTOR2D acceleration, float maxVelocity) : 
	m_motionDirection(none),
	m_prevMotionDirection(none),
	m_velocity(velocity),
	m_acceleration(acceleration),
	m_maxVelocity(maxVelocity),
	m_keepGravityMovement(false)
{
}

void Motion::Update(GameTime& gameTime)
{
	// Reset the movement when the motion direction is switched.
	if ((m_prevMotionDirection != none) && 
		(m_motionDirection != none) && 
		(m_prevMotionDirection != m_motionDirection) && 
		IsMotionChangedToOppositeDirection())
	{
		m_movement = VECTOR2D(0, 0);

		if (m_acceleration != VECTOR2D(0, 0))
		{
			m_velocity = VECTOR2D(0, 0);
		}
	}

	float elapsedTime = gameTime.GetFrameElapsedTime();
	int directionFactor;

	switch (m_motionDirection)
	{
		case left:
		case right:
			directionFactor = (m_motionDirection == left) ? -1 : 1;
			if (m_acceleration.x != 0)
			{
				m_movement.x = (m_velocity.x * directionFactor + m_acceleration.x * elapsedTime * directionFactor / 2) * elapsedTime;
				m_velocity.x += m_acceleration.x * elapsedTime;

				if (m_maxVelocity > 0)
				{
					m_velocity.Limit(m_maxVelocity);
				}
			}
			else
			{
				m_movement.x = m_velocity.x * elapsedTime * directionFactor;
			}
			break;

		case upward:
		case downward:
			directionFactor = (m_motionDirection == upward) ? -1 : 1;
			if (m_acceleration.y != 0)
			{
				m_movement.y = (m_velocity.y * directionFactor + m_acceleration.y * elapsedTime * directionFactor / 2) * elapsedTime;
				m_velocity.y += m_acceleration.y * elapsedTime;

				if (m_maxVelocity > 0)
				{
					m_velocity.Limit(m_maxVelocity);
				}
			}
			else
			{
				m_movement.y = m_velocity.y * elapsedTime * directionFactor;
			}
			break;

		case left_upward:
		case right_downward:
			directionFactor = (m_motionDirection == left_upward) ? -1 : 1;
			if (m_acceleration != VECTOR2D(0, 0))
			{
				m_movement = (m_velocity * directionFactor + m_acceleration * elapsedTime * directionFactor / 2) * elapsedTime;
				m_velocity += m_acceleration * elapsedTime;

				if (m_maxVelocity > 0)
				{
					m_velocity.Limit(m_maxVelocity);
				}
			}
			else
			{
				m_movement = m_velocity * elapsedTime * directionFactor;
			}
			break;

		case left_downward:
			if (m_acceleration != VECTOR2D(0, 0))
			{
				m_movement.x = (m_velocity.x * (-1) + m_acceleration.x * elapsedTime * (-1) / 2) * elapsedTime;
				m_movement.y = (m_velocity.y * 1 + m_acceleration.y * elapsedTime * 1 / 2) * elapsedTime;
				m_velocity += m_acceleration * elapsedTime;

				if (m_maxVelocity > 0)
				{
					m_velocity.Limit(m_maxVelocity);
				}
			}
			else
			{
				m_movement.x = m_velocity.x * elapsedTime * (-1);
				m_movement.y = m_velocity.y * elapsedTime * 1;
			}
			break;

		case right_upward:
			if (m_acceleration != VECTOR2D(0, 0))
			{
				m_movement.x = (m_velocity.x * 1 + m_acceleration.x * elapsedTime * 1 / 2) * elapsedTime;
				m_movement.y = (m_velocity.y * (-1) + m_acceleration.y * elapsedTime * (-1) / 2) * elapsedTime;
				m_velocity += m_acceleration * elapsedTime;

				if (m_maxVelocity > 0)
				{
					m_velocity.Limit(m_maxVelocity);
				}
			}
			else
			{
				m_movement.x = m_velocity.x * elapsedTime * 1;
				m_movement.y = m_velocity.y * elapsedTime * (-1);
			}
			break;

		default:
			if (m_keepGravityMovement)
			{
				// Do NOT reset the vertical movement part. Leave it to the gravity force.
				m_movement.x = 0;
			}
			else
			{
				m_movement = VECTOR2D(0, 0);
			}
			if (m_acceleration != VECTOR2D(0, 0))
			{
				m_velocity = VECTOR2D(0, 0);
			}
			break;
	}

	m_prevMotionDirection = m_motionDirection;
	m_keepGravityMovement = false;
}

bool Motion::IsMotionChangedToOppositeDirection()
{
	// The change in angle between previous and current direction should be OVER 90 deg.
	if ((m_prevMotionDirection == left) && (m_motionDirection == right || m_motionDirection == right_upward || m_motionDirection == right_downward) || 
		(m_prevMotionDirection == right) && (m_motionDirection == left || m_motionDirection == left_upward || m_motionDirection == left_downward) || 
		(m_prevMotionDirection == upward) && (m_motionDirection == downward || m_motionDirection == left_downward || m_motionDirection == right_downward) || 
		(m_prevMotionDirection == downward) && (m_motionDirection == upward || m_motionDirection == left_upward|| m_motionDirection == right_upward))
	{
		return true;
	}

	return false;
}

////////////////////////////////////////////////////////////
// Definitions for the Jumping class.
//
Jumping::Jumping() : 
	m_emptyBehavior(false),
	m_isJumping(false),
	m_isFalling(false),
	m_gravity(0.0),
	m_impulse(0.0),
	m_maxImpulseTime(0.0),
	m_jumpingStartTime(0.0)
{
}

Jumping::Jumping(float gravity, float impulse, float maxImpulseTime) : 
	m_emptyBehavior(false),
	m_isJumping(false),
	m_isFalling(false),
	m_gravity(gravity),
	m_impulse(impulse),
	m_maxImpulseTime(maxImpulseTime),
	m_jumpingStartTime(0.0)
{
}

void Jumping::Update(GameTime& gameTime)
{
	if (m_emptyBehavior)
	{
		m_isJumping = false;
		m_isFalling = false;
		m_movement.x = m_movement.y = 0.0;
		m_velocity.x = m_velocity.y = 0.0;
		return;
	}

	float elapsedTime = gameTime.GetFrameElapsedTime();
	m_movement.y = m_velocity.y * elapsedTime;
	m_velocity.y += m_gravity * elapsedTime;

	// Check for the switch in the vertical move direction during jumping due to the gravity.
	if (m_isJumping && (m_movement.y <= 0) && (m_velocity.y >= 0))
	{
		m_isJumping = false;
		m_isFalling = true;
	}
}

void Jumping::StartJumping(GameTime& gameTime)
{
	if (m_emptyBehavior)
	{
		return;
	}

	m_isJumping = true;
	m_isFalling = false;
	m_jumpingStartTime = gameTime.GetGameElapsedTime();
	m_velocity.y = m_impulse;
}

void Jumping::RetainJumpingIfNeeded(GameTime& gameTime)
{
	if (m_emptyBehavior)
	{
		return;
	}

	if (m_isJumping && (gameTime.GetGameElapsedTime() - m_jumpingStartTime < m_maxImpulseTime))
	{
		m_velocity.y = m_impulse;
	}
}

////////////////////////////////////////////////////////////
// Definitions for the Shooting class.
//
Shooting::Shooting() : 
	m_pShooter(NULL),
	m_type(0),
	m_capacity(0),
	m_pause(0.0),
	m_timeSincePreviousShot(0.0)
{
}

Shooting::Shooting(Actor* pShooter, UINT type, int capacity, float pause) : 
	m_pShooter(pShooter),
	m_type(type),
	m_capacity(capacity),
	m_pause(pause),
	m_timeSincePreviousShot(0.0)
{
}

void Shooting::Shoot(GameTime& gameTime)
{
	if (m_pShooter == NULL)
	{
		throw GameException(_T("Invalid internal shooter pointer."));
	}

	if (m_capacity <= 0)
	{
		return;
	}

	if (gameTime.GetGameElapsedTime() - m_timeSincePreviousShot < m_pause)
	{
		return;
	}

	Projectile* pProjectile = GetGameApp()->GetSceneManager().GetAvailableProjectile(m_type);
	if (pProjectile == NULL)
	{
		return;
	}

	m_timeSincePreviousShot = gameTime.GetGameElapsedTime();

	Motion::MotionDirection motionDirection;
	VECTOR2D from;
	RECTF shooterBounds = m_pShooter->GetBounds();
	RECTF projectileBounds = pProjectile->GetBounds();

	switch (m_pShooter->GetHeading())
	{
		case MovableEntity::left:
			motionDirection = Motion::left;
			from.x = shooterBounds.left - projectileBounds.Width();
			from.y = shooterBounds.top + shooterBounds.Height() / 2 - projectileBounds.Height() / 2;
			break;

		case MovableEntity::right:
			motionDirection = Motion::right;
			from.x = shooterBounds.right + 0.1f;
			from.y = shooterBounds.top + shooterBounds.Height() / 2 - projectileBounds.Height() / 2;
			break;

		case MovableEntity::up:
			motionDirection = Motion::upward;
			from.x = shooterBounds.left + shooterBounds.Width() / 2 - projectileBounds.Width() / 2;
			from.y = shooterBounds.top - projectileBounds.Height();
			break;

		case MovableEntity::down:
			motionDirection = Motion::downward;
			from.x = shooterBounds.left + shooterBounds.Width() / 2 - projectileBounds.Width() / 2;
			from.y = shooterBounds.bottom + 0.1f;
			break;
	}

	pProjectile->SetShooter(m_pShooter);
	pProjectile->ResetPosition(from);
	pProjectile->GetMotion().SetMotionDirection(motionDirection);
	pProjectile->SetIsActive(true);
	pProjectile->SetIsVisible(true);

	--m_capacity;
}

////////////////////////////////////////////////////////////
// Definitions for the Wandering class.
//
Wandering::Wandering() : 
	m_aheadCircleDistance(100),
	m_aheadCircleRadius(10),
	m_displacementAngle(0),
	m_displacementAngleChange(0.8)
{
	srand(time(NULL));
}

Wandering::Wandering(float aheadCircleDistance, float aheadCircleRadius, float displacementAngleChange) : 
	m_aheadCircleDistance(aheadCircleDistance),
	m_aheadCircleRadius(aheadCircleRadius),
	m_displacementAngle(0),
	m_displacementAngleChange(displacementAngleChange)
{
}

VECTOR2D Wandering::Perform(Agent* pAgent)
{
	// Calculate the ahead circle center.
	// Since the circle should be placed in front of the agent, the velocity vector can be used as a direction.
	VECTOR2D aheadCircleCenter = pAgent->m_velocity;
	aheadCircleCenter.Normalize();
	aheadCircleCenter *= m_aheadCircleDistance;

	// Calculate the displacement force, which is responsible for the right or left turn.
	// Use a vector aligned with the Y axis pointing up.
	VECTOR2D displacement = VECTOR2D(0, -1);
	displacement *= m_aheadCircleRadius;

	// Randomly change the vector direction by making it change its current angle.
	float curDisplacementAmount = displacement.Magnitude();
	displacement.x = curDisplacementAmount * cos(m_displacementAngle);
	displacement.y = curDisplacementAmount * sin(m_displacementAngle);

	// Change the m_displacementAngle just a bit, so it won't have the same value in the next game frame.
	m_displacementAngle += (rand() % 3) * m_displacementAngleChange - m_displacementAngleChange * 0.5;

	// Calculate the wander force.
	VECTOR2D wanderForce = aheadCircleCenter + displacement;

	return wanderForce;
}

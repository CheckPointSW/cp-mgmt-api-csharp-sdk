#pragma once

#include "GSEngineExports.h"
#include "Entity.h"
#include "GameTime.h"
#include "Behaviors.h"

////////////////////////////////////////////////////////////
// Declaration of the Agent class.
//
class GSENGINE_API Agent : public Entity
{
	// Provide an access to Agent's private members for the followings:
	friend class Wandering;

public:
	// Construction
	Agent();
	virtual ~Agent();

	// Methods
	virtual void Cleanup();
	virtual void Update(GameTime& gameTime);
	void AddWandering();
	Wandering& GetWandering() { return *m_pWander; }

	// Attributes
	VECTOR2D GetVelocity() const { return m_velocity; }
	void SetVelocity(VECTOR2D velocity) { m_velocity = velocity; }

private:
	Wandering* m_pWander;
	VECTOR2D m_velocity;
};

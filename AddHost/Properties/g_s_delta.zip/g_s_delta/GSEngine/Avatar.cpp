#include "stdafx.h"
#include "Avatar.h"
#include "GameException.h"
#include "Model.h"

////////////////////////////////////////////////////////////
// Definitions for the Avatar class.
//
Avatar::Avatar() : 
	m_pJumping(NULL),
	m_score(0)
{
}

Avatar::~Avatar()
{
	Cleanup();
}

void Avatar::Cleanup()
{
	if (m_pJumping != NULL)
	{
		delete m_pJumping;
		m_pJumping = NULL;
	}

	Actor::Cleanup();
}

void Avatar::Update(GameTime& gameTime)
{
	Entity::Update(gameTime);

	VECTOR2D movement;

	if (m_pJumping != NULL)
	{
		m_pJumping->Update(gameTime);
		movement += m_pJumping->GetMovement();
	}

	if (m_pMotion != NULL)
	{
		if ((m_pJumping != NULL) && (m_pJumping->GetIsJumping() || m_pJumping->GetIsFalling()))
		{
			m_pMotion->m_keepGravityMovement = true;
		}

		m_pMotion->Update(gameTime);
		movement += m_pMotion->GetMovement();
	}

	VECTOR2D curPosition = m_pModel->GetPosition();
	curPosition += movement;
	m_pModel->Update(curPosition);
}

void Avatar::AddJumping(float gravity, float impulse, float maxImpulseTime)
{
	if (m_pJumping == NULL)
	{
		m_pJumping = new Jumping(gravity, impulse, maxImpulseTime);
	}
}

Jumping& Avatar::GetJumping()
{
	if (m_pJumping == NULL)
	{
		// The AddJumping method was not invoked, so create an empty behavior!!!
		m_pJumping = new Jumping();
		m_pJumping->m_emptyBehavior = true;
	}

	return *m_pJumping;
}

void Avatar::ResolveCollision(VECTOR2D position, VECTOR2D velocity, bool isJumping, bool isFalling)
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	if (!m_isActive || !m_isVisible)
	{
		return;
	}

	m_pModel->Update(position);
	m_pMotion->SetMotionDirection(Motion::none);

	if (m_pMotion->GetAcceleration() != VECTOR2D(0, 0))
	{
		m_pMotion->SetVelocity(velocity);
	}

	if (m_pJumping != NULL)
	{
		m_pJumping->m_velocity = velocity;
		m_pJumping->m_isJumping = isJumping;
		m_pJumping->m_isFalling = isFalling;
	}
}

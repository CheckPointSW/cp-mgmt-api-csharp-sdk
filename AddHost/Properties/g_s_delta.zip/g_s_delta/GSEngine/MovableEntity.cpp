#include "stdafx.h"
#include "MovableEntity.h"
#include "GameException.h"
#include "Model.h"

////////////////////////////////////////////////////////////
// Definitions for the MovableEntity class.
//
MovableEntity::MovableEntity() : 
	m_pMotion(NULL),
	m_heading(right)
{
}

MovableEntity::~MovableEntity()
{
	Cleanup();
}

void MovableEntity::Cleanup()
{
	if (m_pMotion != NULL)
	{
		delete m_pMotion;
		m_pMotion = NULL;
	}

	Entity::Cleanup();
}

void MovableEntity::Update(GameTime& gameTime)
{
	Entity::Update(gameTime);

	if (m_pMotion != NULL)
	{
		m_pMotion->Update(gameTime);

		VECTOR2D curPosition = m_pModel->GetPosition();
		curPosition += m_pMotion->GetMovement();
		m_pModel->Update(curPosition);
	}
}

void MovableEntity::Draw(GameTime& gameTime)
{
	m_interpolation = 0.0f;

	if ((m_pMotion != NULL) && (m_pMotion->GetMotionDirection() != none))
	{
		m_interpolation = gameTime.GetFrameLeftOverTime() / gameTime.GetFrameElapsedTime();   // inter-frame transposition
	}

	Entity::Draw(gameTime);
}

void MovableEntity::AddMotion(VECTOR2D velocity, VECTOR2D acceleration, float maxVelocity)
{
	if (m_pMotion == NULL)
	{
		m_pMotion = new Motion(velocity, acceleration, maxVelocity);
	}
}

#pragma once

#include "GSEngineExports.h"
#include "Actor.h"
#include "Behaviors.h"

////////////////////////////////////////////////////////////
// Declaration of the Avatar class.
//
class GSENGINE_API Avatar : public Actor
{
	// Provide an access to GameApp's private members for the followings:
	friend class CollisionDetector;

public:
	// Construction
	Avatar();
	virtual ~Avatar();

	// Methods
	virtual void Cleanup();
	virtual void Update(GameTime& gameTime);
	void AddJumping(float gravity, float impulse, float maxImpulseTime);
	Jumping& GetJumping();

	// Attributes
	int GetScore() const { return m_score; }
	void SetScore(int score) { m_score = score; }

private:
	void ResolveCollision(VECTOR2D position, VECTOR2D velocity, bool isJumping, bool isFalling);

private:
	Jumping* m_pJumping;
	int m_score;
};

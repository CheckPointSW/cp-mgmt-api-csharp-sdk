#pragma once

#include "GSEngineExports.h"
#include "GSGraphicsTypes.h"
#include "Entity.h"
#include "GameTime.h"
#include "Behaviors.h"

////////////////////////////////////////////////////////////
// Declaration of the MovableEntity class.
//
class GSENGINE_API MovableEntity : public Entity
{
public:
	enum Heading
	{
		left, right, up, down
	};

public:
	// Construction
	MovableEntity();
	virtual ~MovableEntity();

	// Methods
	virtual void Cleanup();
	virtual void Update(GameTime& gameTime);
	virtual void Draw(GameTime& gameTime);
	void AddMotion(VECTOR2D velocity, VECTOR2D acceleration, float maxVelocity);
	Motion& GetMotion() { return *m_pMotion; }

	// Attributes
	Heading GetHeading() const { return m_heading; }
	void SetHeading(Heading heading) { m_heading = heading; }

protected:
	Motion* m_pMotion;
	Heading m_heading;
};

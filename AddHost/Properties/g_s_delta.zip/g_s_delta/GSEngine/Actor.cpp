#include "stdafx.h"
#include "Actor.h"

////////////////////////////////////////////////////////////
// Definitions for the Actor class.
//
Actor::Actor() : 
	m_pShooting(NULL),
	m_health(0)
{
}

Actor::~Actor()
{
	Cleanup();
}

void Actor::Cleanup()
{
	if (m_pShooting != NULL)
	{
		delete m_pShooting;
		m_pShooting = NULL;
	}

	MovableEntity::Cleanup();
}

void Actor::AddShooting(UINT type, int capacity, float delay)
{
	if (m_pShooting == NULL)
	{
		m_pShooting = new Shooting(this, type, capacity, delay);
	}
}

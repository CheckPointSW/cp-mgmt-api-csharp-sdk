#include "stdafx.h"
#include "Agent.h"
#include "Model.h"

////////////////////////////////////////////////////////////
// Definitions for the Agent class.
//
Agent::Agent() : m_pWander(NULL)
{
}

Agent::~Agent()
{
	Cleanup();
}

void Agent::Cleanup()
{
	if (m_pWander != NULL)
	{
		delete m_pWander;
		m_pWander = NULL;
	}

	Entity::Cleanup();
}

void Agent::Update(GameTime& gameTime)
{
	Entity::Update(gameTime);

	VECTOR2D steering;

	if (m_pWander != NULL)
	{
		steering += m_pWander->Perform(this);
	}

	steering.Limit(0.5);

	m_velocity += steering;
	m_velocity.Limit(10);
	
	VECTOR2D curPosition = m_pModel->GetPosition();
	curPosition += m_velocity;
	m_pModel->Update(curPosition);
}

void Agent::AddWandering()
{
	if (m_pWander == NULL)
	{
		m_pWander = new Wandering();
	}
}

#pragma once

#include "GSEngineExports.h"
#include "GSGraphicsTypes.h"
#include "MovableEntity.h"
#include "Behaviors.h"

using namespace std;

////////////////////////////////////////////////////////////
// Declaration of the Actor class.
//
class GSENGINE_API Actor : public MovableEntity
{
public:
	// Construction
	Actor();
	virtual ~Actor();

	// Methods
	virtual void Cleanup();
	void AddShooting(UINT type, int capacity, float delay);
	Shooting& GetShooting() { return *m_pShooting; }

	// Attributes
	int GetHealth() const { return m_health; }
	void SetHealth(int health) { m_health = health; }

protected:
	Shooting* m_pShooting;
	int m_health;
};

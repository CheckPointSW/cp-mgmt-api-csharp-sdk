#include "stdafx.h"
#include "Entity.h"
#include "GameApp.h"
#include "GameException.h"
#include "GraphicsManager.h"
#include "GameAssets.h"
#include "Model.h"
#include "Texture.h"

////////////////////////////////////////////////////////////
// Definitions for the Entity class.
//
Entity::Entity() : 
	m_name(_T("")),
	m_imageName(_T("")),
	m_type(0),
	m_interaction(none),
	m_interpolation(0.0),
	m_isActive(true),
	m_isVisible(true),
	m_isPlayingAnimation(false),
	m_pModel(NULL),
	m_pCurrentAnimation(NULL)
{
}

Entity::~Entity()
{
	Cleanup();
}

bool Entity::Initialize(wstring name, UINT type, wstring imageName, VECTOR2D position, Interaction interaction)
{
	m_name = name;
	m_imageName = imageName;
	m_type = type;
	m_interaction = interaction;

	Image& image = GetGameApp()->GetAssetsManager().GetImage(imageName);
	SIZE modelSize;
	m_pModel = new Model();

	if (image.GetNumberOfAnimations() == 0)
	{
		modelSize = image.GetTexture()->GetSize();
	}
	else
	{
		modelSize.cx = image.GetAnimationFrameWidth();
		modelSize.cy = image.GetAnimationFrameHeight();
	}

	if (!GetGameApp()->m_graphicsManager.InitializeModel(*m_pModel, modelSize, position))
	{
		Cleanup();

		wstring error = _T("Cannot initialize a model object associated with the game entity '") + m_name + _T("'.");
		throw GameException(error);
	}

	return true;
}

void Entity::Cleanup()
{
	if (m_pModel != NULL)
	{
		m_pModel->Cleanup();

		delete m_pModel;
		m_pModel = NULL;
	}

	for (unordered_map<wstring, AnimationScheduler*>::iterator iter = m_animations.begin(); iter != m_animations.end(); iter++)
	{
		delete iter->second;
	}
	m_animations.clear();
}

void Entity::Update(GameTime& gameTime)
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	if (!m_isActive)
	{
		return;
	}

	if (m_pCurrentAnimation != NULL)
	{
		m_pCurrentAnimation->Update(gameTime);

		if (m_pCurrentAnimation->IsEnded())
		{
			m_isPlayingAnimation = false;
		}
	}
}

void Entity::Draw(GameTime& gameTime)
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	if (!m_isActive || !m_isVisible)
	{
		return;
	}

	Image& image = GetGameApp()->GetAssetsManager().GetImage(m_imageName);

	RECTF textureSourceRect(0, 0, 1, 1);   // whole texture is rendered
	if (m_pCurrentAnimation != NULL)
	{
		// Only a part of texture is rendered.
		textureSourceRect = AnimationScheduler::GetAnimatedTextureFrameRect(image, *m_pCurrentAnimation);
	}

	m_pModel->Render(m_interpolation, textureSourceRect);
	GetGameApp()->m_graphicsManager.DrawGameEntity(*(image.GetTexture()), *m_pModel);
}

void Entity::ResetPosition(VECTOR2D position)
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	m_pModel->ResetPosition(position);
}


void Entity::AddAnimation(wstring name, int index, int startFrame, int numberOfFrames, int framesPerSecond, bool isLooping)
{
	Image& image = GetGameApp()->GetAssetsManager().GetImage(m_imageName);

	if (image.GetNumberOfAnimations() == 0)
	{
		wstring error = _T("There are no animations specified for image resource '") + image.GetImageFileName() + _T(".");
		throw GameException(error);
	}

	if ((index < 0) || (index >= image.GetNumberOfAnimations()))
	{
		wstring error = _T("Invalid animation index for animation '") + name + _T(".");
		throw GameException(error);
	}

	if (startFrame + numberOfFrames * image.GetAnimationFrameWidth() > image.GetTexture()->GetSize().cx)
	{
		wstring error = _T("Invalid number of animation frames for animation '") + name + _T(".");
		throw GameException(error);
	}

	unordered_map<wstring, AnimationScheduler*>::iterator iter = m_animations.find(name);
	if (iter != m_animations.end())
	{
		wstring error = _T("Animation with name '") + name + _T("' already exists.");
		throw GameException(error);
	}

	AnimationScheduler* pAnimationFrame = new AnimationScheduler(name, index, startFrame, numberOfFrames, framesPerSecond, isLooping);

	m_animations.insert(make_pair(name, pAnimationFrame));
}

void Entity::PlayAnimation(wstring name, bool replay)
{
	m_isPlayingAnimation = false;

	unordered_map<wstring, AnimationScheduler*>::iterator iter = m_animations.find(name);
	if (iter != m_animations.end())
	{
		// Ensure that it is NOT the same animation.
		if (m_pCurrentAnimation != iter->second)
		{
			m_pCurrentAnimation = iter->second;
			m_pCurrentAnimation->Reset();
			m_isPlayingAnimation = true;
		}
		else if (replay)
		{
			m_pCurrentAnimation->Reset();
			m_isPlayingAnimation = true;
		}
	}
	else
	{
		m_pCurrentAnimation = NULL;
	}
}

VECTOR2D Entity::GetPosition() const
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	return m_pModel->GetPosition();
}

RECTF Entity::GetBounds() const
{
	if (m_pModel == NULL)
	{
		throw GameException(_T("Invalid internal model pointer."));
	}

	VECTOR2D pos = m_pModel->GetPosition();
	SIZE size = m_pModel->GetSize();
	return RECTF(pos.x, pos.y, pos.x + size.cx, pos.y + size.cy);
}
